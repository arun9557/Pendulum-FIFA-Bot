"""Participant bot package."""
